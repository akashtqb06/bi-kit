--
-- PostgreSQL database dump
--

\restrict cPcnYnBlIW0PYQJ8ghZaNZG3cx3ud9072didJJv0vemTMi6inO6SPaPWrLk18Ua

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA drizzle;


ALTER SCHEMA drizzle OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: postgres
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


ALTER TABLE drizzle.__drizzle_migrations OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: postgres
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: postgres
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_settings (
    key text NOT NULL,
    value jsonb NOT NULL
);


ALTER TABLE public.app_settings OWNER TO postgres;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_log (
    id text NOT NULL,
    user_id text,
    action text NOT NULL,
    data_source_id text,
    host text,
    at timestamp with time zone DEFAULT now() NOT NULL,
    details jsonb,
    ip_address text
);


ALTER TABLE public.audit_log OWNER TO postgres;

--
-- Name: charts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.charts (
    id text NOT NULL,
    workbook_id text NOT NULL,
    query_id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    folder_id text,
    "position" integer DEFAULT 0 NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.charts OWNER TO postgres;

--
-- Name: dashboard_favorites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dashboard_favorites (
    user_id text NOT NULL,
    dashboard_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dashboard_favorites OWNER TO postgres;

--
-- Name: dashboard_views; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dashboard_views (
    user_id text NOT NULL,
    dashboard_id text NOT NULL,
    view_count integer DEFAULT 0 NOT NULL,
    last_viewed_at timestamp with time zone
);


ALTER TABLE public.dashboard_views OWNER TO postgres;

--
-- Name: dashboards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dashboards (
    id text NOT NULL,
    workbook_id text NOT NULL,
    owner_id text NOT NULL,
    name text NOT NULL,
    slug text,
    layout jsonb DEFAULT '[]'::jsonb NOT NULL,
    filters jsonb DEFAULT '[]'::jsonb NOT NULL,
    auto_refresh text DEFAULT 'off'::text NOT NULL,
    folder_id text,
    "position" integer DEFAULT 0 NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dashboards OWNER TO postgres;

--
-- Name: data_sources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.data_sources (
    id text NOT NULL,
    owner_id text NOT NULL,
    name text NOT NULL,
    slug text,
    type text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'unknown'::text NOT NULL,
    last_tested_at timestamp with time zone,
    last_error text,
    server_version text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.data_sources OWNER TO postgres;

--
-- Name: data_store_syncs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.data_store_syncs (
    id text NOT NULL,
    table_id text NOT NULL,
    status text NOT NULL,
    rows_synced integer DEFAULT 0 NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    error text,
    triggered_by text DEFAULT 'manual'::text NOT NULL
);


ALTER TABLE public.data_store_syncs OWNER TO postgres;

--
-- Name: data_store_tables; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.data_store_tables (
    id text NOT NULL,
    owner_id text NOT NULL,
    data_source_id text,
    query_id text,
    kind text DEFAULT 'table'::text NOT NULL,
    source_table text NOT NULL,
    store_schema text NOT NULL,
    store_table text NOT NULL,
    columns jsonb DEFAULT '[]'::jsonb NOT NULL,
    row_count integer DEFAULT 0 NOT NULL,
    size_bytes bigint DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    last_synced_at timestamp with time zone,
    last_error text,
    schedule text DEFAULT 'manual'::text NOT NULL,
    sync_mode text DEFAULT 'full'::text NOT NULL,
    cursor_column text,
    last_watermark text,
    indexed_columns jsonb DEFAULT '[]'::jsonb NOT NULL,
    included_columns jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.data_store_tables OWNER TO postgres;

--
-- Name: fin_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fin_accounts (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    kind text NOT NULL,
    class text NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    credit_limit bigint,
    is_active boolean DEFAULT true NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.fin_accounts OWNER TO postgres;

--
-- Name: fin_budgets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fin_budgets (
    id text NOT NULL,
    user_id text NOT NULL,
    category_id text NOT NULL,
    amount bigint NOT NULL,
    period text DEFAULT 'monthly'::text NOT NULL,
    start_date date NOT NULL,
    end_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.fin_budgets OWNER TO postgres;

--
-- Name: fin_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fin_categories (
    id text NOT NULL,
    user_id text,
    name text NOT NULL,
    type text NOT NULL,
    parent_id text,
    icon text,
    color text,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.fin_categories OWNER TO postgres;

--
-- Name: fin_recurring_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fin_recurring_rules (
    id text NOT NULL,
    user_id text NOT NULL,
    account_id text NOT NULL,
    to_account_id text,
    category_id text,
    type text NOT NULL,
    amount bigint NOT NULL,
    payee text,
    note text,
    frequency text NOT NULL,
    "interval" integer DEFAULT 1 NOT NULL,
    start_date date NOT NULL,
    end_date date,
    next_occurrence date NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.fin_recurring_rules OWNER TO postgres;

--
-- Name: fin_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fin_transactions (
    id text NOT NULL,
    user_id text NOT NULL,
    account_id text NOT NULL,
    to_account_id text,
    category_id text,
    date date NOT NULL,
    type text NOT NULL,
    amount bigint NOT NULL,
    signed_amount bigint NOT NULL,
    payee text,
    note text,
    tags text,
    client_request_id text,
    import_hash text,
    is_recurring boolean DEFAULT false NOT NULL,
    recurring_rule_id text,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT fin_transactions_amount_check CHECK (((type = 'adjustment'::text) OR (amount > 0))),
    CONSTRAINT fin_transactions_transfer_check CHECK (((type <> 'transfer'::text) OR ((to_account_id IS NOT NULL) AND (to_account_id <> account_id))))
);


ALTER TABLE public.fin_transactions OWNER TO postgres;

--
-- Name: fin_user_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fin_user_settings (
    user_id text NOT NULL,
    base_currency text DEFAULT 'INR'::text NOT NULL,
    timezone text DEFAULT 'Asia/Kolkata'::text NOT NULL,
    week_starts_on integer DEFAULT 1 NOT NULL,
    tracking_start_date date,
    setup_step integer DEFAULT 1 NOT NULL,
    setup_completed_at timestamp with time zone,
    setup_skipped_at timestamp with time zone,
    draft jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.fin_user_settings OWNER TO postgres;

--
-- Name: fin_valuations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fin_valuations (
    id text NOT NULL,
    account_id text NOT NULL,
    date date NOT NULL,
    value bigint NOT NULL,
    cost_basis bigint,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.fin_valuations OWNER TO postgres;

--
-- Name: folders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.folders (
    id text NOT NULL,
    workbook_id text NOT NULL,
    kind text NOT NULL,
    name text NOT NULL,
    parent_id text,
    "position" integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.folders OWNER TO postgres;

--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.login_attempts (
    id text NOT NULL,
    key text NOT NULL,
    attempted_at timestamp with time zone DEFAULT now() NOT NULL,
    success boolean DEFAULT false NOT NULL
);


ALTER TABLE public.login_attempts OWNER TO postgres;

--
-- Name: queries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.queries (
    id text NOT NULL,
    workbook_id text NOT NULL,
    name text NOT NULL,
    data_source_id text NOT NULL,
    mode text DEFAULT 'sql'::text NOT NULL,
    definition jsonb DEFAULT '[]'::jsonb NOT NULL,
    sql text DEFAULT ''::text NOT NULL,
    folder_id text,
    "position" integer DEFAULT 0 NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.queries OWNER TO postgres;

--
-- Name: schema_cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schema_cache (
    data_source_id text NOT NULL,
    snapshot jsonb NOT NULL,
    fetched_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.schema_cache OWNER TO postgres;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    user_id text NOT NULL,
    token_hash text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    last_used_at timestamp with time zone DEFAULT now() NOT NULL,
    ip_address text,
    user_agent text
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'member'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    avatar_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_login_at timestamp with time zone,
    must_change_password boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: workbooks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workbooks (
    id text NOT NULL,
    owner_id text NOT NULL,
    name text NOT NULL,
    slug text,
    description text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.workbooks OWNER TO postgres;

--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: postgres
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: postgres
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
1	7b4337e53a6bd27ac75cf144346a5defae9cfd501c47de8804a4b965e7335b6b	1793183086587
2	e3d31476ccbdd53708405c5a6de9164e38ed8de5b295415f678b5c627343ffad	1793189108012
3	119634d1a5c4c98a10ebbcce3540031e20ce7a05df2717bd0d1f519ad4cc348b	1793284539621
4	3c3d4e2534f672f45d514f1763cd8ecc1043a85e7607a880eea13f424b932831	1793284772441
5	faec30309d796eeebba2e1ca1e97d0ba2bc291d200914f52fe946796474df55f	1793294394233
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.app_settings (key, value) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_log (id, user_id, action, data_source_id, host, at, details, ip_address) FROM stdin;
Uuu47QSf9PPZbFiq4isrk	\N	auth.login_failed	\N	\N	2026-10-30 00:17:20.217+05:30	{"email": "admin@example.com", "reason": "invalid_credentials"}	172.18.0.1
cRTw2KpN6HpYqyKydsFaG	eac4d6164bf243198084a861	auth.login	\N	\N	2026-10-30 00:18:14.511+05:30	\N	172.18.0.1
\.


--
-- Data for Name: charts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.charts (id, workbook_id, query_id, name, type, config, folder_id, "position", created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dashboard_favorites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dashboard_favorites (user_id, dashboard_id, created_at) FROM stdin;
\.


--
-- Data for Name: dashboard_views; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dashboard_views (user_id, dashboard_id, view_count, last_viewed_at) FROM stdin;
\.


--
-- Data for Name: dashboards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dashboards (id, workbook_id, owner_id, name, slug, layout, filters, auto_refresh, folder_id, "position", created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: data_sources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.data_sources (id, owner_id, name, slug, type, config, status, last_tested_at, last_error, server_version, created_at, updated_at) FROM stdin;
RSnZOSeFecmg9ZJjiPwlp	eac4d6164bf243198084a861	Data Store	datastore-eac4d6164bf243198084a861	datastore	{"userId": "eac4d6164bf243198084a861", "isBuiltin": true}	ok	\N	\N	\N	2026-10-30 00:47:00.418493+05:30	2026-10-30 00:47:00.418493+05:30
\.


--
-- Data for Name: data_store_syncs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.data_store_syncs (id, table_id, status, rows_synced, started_at, finished_at, error, triggered_by) FROM stdin;
\.


--
-- Data for Name: data_store_tables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.data_store_tables (id, owner_id, data_source_id, query_id, kind, source_table, store_schema, store_table, columns, row_count, size_bytes, status, last_synced_at, last_error, schedule, sync_mode, cursor_column, last_watermark, indexed_columns, included_columns, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fin_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fin_accounts (id, user_id, name, kind, class, currency, credit_limit, is_active, metadata, created_at, updated_at) FROM stdin;
NjNv592BrqxfzvA6LxZS7	eac4d6164bf243198084a861	SBI Salary	bank	asset	INR	\N	t	{"institution": "SBI", "openingDate": "2026-10-30", "openingBalancePaise": 500000}	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
KQWpsA9R2izqk8Z7Sm3dT	eac4d6164bf243198084a861	ICICI Savings	bank	asset	INR	\N	t	{"institution": "ICICI", "openingDate": "2026-10-30", "openingBalancePaise": 803185}	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
lMmIRpPtUyeMuu07CvQ16	eac4d6164bf243198084a861	Indian Bank Savings	bank	asset	INR	\N	t	{"institution": "Indian Bank", "openingDate": "2026-10-30", "openingBalancePaise": 2772347}	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
UcVUaB3fB9Hr1UEcaSsW0	eac4d6164bf243198084a861	Fastrack Wallet	cash	asset	INR	\N	t	{"institution": "Indian Bank", "openingDate": "2026-10-30", "openingBalancePaise": 100000}	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
oGSz80b8tFehRQXvymATL	eac4d6164bf243198084a861	Flipkart SBI card	credit_card	liability	INR	17000000	t	{"dueDay": 15, "institution": "SBI", "openingDate": "2026-10-30", "statementDay": 13, "openingBalancePaise": -191275}	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
7jClmm1R7aOFBDZncFRGX	eac4d6164bf243198084a861	Amazon pay ICICI	credit_card	liability	INR	5000000	t	{"dueDay": 15, "institution": "ICICI", "openingDate": "2026-10-30", "statementDay": 20, "openingBalancePaise": -215900}	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
67s9x7MOdc5r82W5ajZhs	eac4d6164bf243198084a861	Swiggy Ornge HDFC	credit_card	liability	INR	9100000	t	{"dueDay": 15, "institution": "HDFC", "openingDate": "2026-10-30", "statementDay": 23, "openingBalancePaise": -394625}	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
GhxaC7BiwNVjbogCdm1Sq	eac4d6164bf243198084a861	Groww Stocks	stocks	asset	INR	\N	t	{"institution": "Groww", "openingDate": "2026-10-30", "openingBalancePaise": 4863535, "openingValuationPaise": 5221300, "openingContributionPaise": 4863535}	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
bz6r2FNnApsKuBt7jDn5A	eac4d6164bf243198084a861	Groww Mutual Funds	mutual_fund	asset	INR	\N	t	{"institution": "Groww", "openingDate": "2026-10-30", "openingBalancePaise": 9199500, "openingValuationPaise": 8693400, "openingContributionPaise": 9199500}	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
4EPoTUD9RdfYRCs4NwDiu	eac4d6164bf243198084a861	ICICI RD	recurring_deposit	asset	INR	\N	t	{"startDate": "2026-08-18", "institution": "ICICI", "openingDate": "2026-08-18", "interestRate": 6.5, "tenureMonths": 27, "openingBalancePaise": 1500000, "monthlyInstallmentPaise": 500000}	2026-10-30 00:42:52.727+05:30	2026-10-30 13:11:41.911+05:30
\.


--
-- Data for Name: fin_budgets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fin_budgets (id, user_id, category_id, amount, period, start_date, end_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fin_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fin_categories (id, user_id, name, type, parent_id, icon, color, is_system, created_at, updated_at) FROM stdin;
b14930669085799f719ecb32	\N	Food & Dining	expense	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
a7a0b56e1bd87db136173401	\N	Groceries	expense	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
83aa06386158351cea55b49f	\N	Transport	expense	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
2cd811976c40f83a417f3ce6	\N	Fuel	expense	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
442916c84e72e0740473c935	\N	Rent	expense	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
ca95e10a09edf066e60ac041	\N	Utilities	expense	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
1b10e337ef6391ea01beb611	\N	Shopping	expense	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
f41cdf0514b77bbb48e745a1	\N	Health	expense	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
f7d574255e0d75539ef78088	\N	Entertainment	expense	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
3a9246b52dcee68bbf098065	\N	Travel	expense	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
1f21de748fd3f21125f8f8df	\N	EMI & Loans	expense	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
8342dd89165bae6339c7ba21	\N	Education	expense	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
1aae4250304c3c437991e679	\N	Insurance	expense	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
2a8a4c3d7f247506509437c3	\N	Subscriptions	expense	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
b7c2de6b634903c0d98e0e28	\N	Fees & Interest	expense	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
60001d16a2f2e86452808b27	\N	Others	expense	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
3b6d8276ef0cd90d7a3fd355	\N	Salary	income	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
d22f100036b6d3f2737524d8	\N	Interest	income	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
6a1d8be6dde49ea03657c934	\N	Dividends	income	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
6e3a9db4005b02a4252e30a1	\N	Refunds	income	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
279507d2fd04d9d7b42a6713	\N	Other income	income	\N	\N	\N	t	2026-10-30 00:10:06.074+05:30	2026-10-30 00:10:06.074+05:30
aXH3uVP0RE4wdaaEkRoU0	eac4d6164bf243198084a861	Food & Dining	expense	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
s2F5wZlauUshWaxdjEVGm	eac4d6164bf243198084a861	Groceries	expense	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
z6tSml5X08x3exLYsTXw8	eac4d6164bf243198084a861	Transport	expense	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
qc5SlDxhQ3iC3XKPImPW0	eac4d6164bf243198084a861	Fuel	expense	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
si1v6N4ldVNWJURbzez4W	eac4d6164bf243198084a861	Rent	expense	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
4hzA3zehGNQUtQ1dJSNnw	eac4d6164bf243198084a861	Utilities	expense	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
GRDo5u1iDV9HVTxdfvfUr	eac4d6164bf243198084a861	Shopping	expense	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
gdvPGOchQPJJltXmxmBE2	eac4d6164bf243198084a861	Health	expense	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
3NAtiBvgFYIssxZszaJxu	eac4d6164bf243198084a861	Entertainment	expense	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
1L9nXVs72tYxKQR6BQNlL	eac4d6164bf243198084a861	Travel	expense	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
eVbkQNBBNQ5UnhUFM4Jb0	eac4d6164bf243198084a861	EMI & Loans	expense	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
6IYSFqKkzFKAmVnDuylQs	eac4d6164bf243198084a861	Education	expense	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
zFQHaoicBAJvpvrhF5X6d	eac4d6164bf243198084a861	Insurance	expense	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
hTJZnG3kD1EQn775NRz2p	eac4d6164bf243198084a861	Subscriptions	expense	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
W2tpLhns6yFGc1mr5yDNY	eac4d6164bf243198084a861	Fees & Interest	expense	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
ZScxOVheGEaTBlsPrfaDP	eac4d6164bf243198084a861	Others	expense	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
0RyWI5PGX8hdksozni9NR	eac4d6164bf243198084a861	Salary	income	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
DjQoLsgqLtTL4N8nNSg1M	eac4d6164bf243198084a861	Interest	income	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
R1r6eylcgFi2NjxX2zfsE	eac4d6164bf243198084a861	Dividends	income	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
0Yr5H3mcBqYHy6d7D8Mc1	eac4d6164bf243198084a861	Refunds	income	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
AMbCVNN6Y1Wc6RlyT4LF9	eac4d6164bf243198084a861	Other income	income	\N	\N	\N	f	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
\.


--
-- Data for Name: fin_recurring_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fin_recurring_rules (id, user_id, account_id, to_account_id, category_id, type, amount, payee, note, frequency, "interval", start_date, end_date, next_occurrence, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fin_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fin_transactions (id, user_id, account_id, to_account_id, category_id, date, type, amount, signed_amount, payee, note, tags, client_request_id, import_hash, is_recurring, recurring_rule_id, deleted_at, created_at, updated_at) FROM stdin;
doFInedgwKyEOrUcko8iV	eac4d6164bf243198084a861	NjNv592BrqxfzvA6LxZS7	\N	\N	2026-10-30	adjustment	500000	500000	Opening Balance	Initial balance as of 2026-10-30	\N	\N	\N	f	\N	\N	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
r2uzOmdvJxLiFFcWDpgSu	eac4d6164bf243198084a861	KQWpsA9R2izqk8Z7Sm3dT	\N	\N	2026-10-30	adjustment	803185	803185	Opening Balance	Initial balance as of 2026-10-30	\N	\N	\N	f	\N	\N	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
QqdkWpakhsiLyfOa91y59	eac4d6164bf243198084a861	lMmIRpPtUyeMuu07CvQ16	\N	\N	2026-10-30	adjustment	2772347	2772347	Opening Balance	Initial balance as of 2026-10-30	\N	\N	\N	f	\N	\N	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
KdXwTqY9wAa5FuL77K8oR	eac4d6164bf243198084a861	UcVUaB3fB9Hr1UEcaSsW0	\N	\N	2026-10-30	adjustment	100000	100000	Opening Balance	Initial balance as of 2026-10-30	\N	\N	\N	f	\N	\N	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
Oac8nbTedlNbVvP4F7zAL	eac4d6164bf243198084a861	oGSz80b8tFehRQXvymATL	\N	\N	2026-10-30	adjustment	191275	-191275	Opening Balance	Initial balance as of 2026-10-30	\N	\N	\N	f	\N	\N	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
6h80BQXwWk8Kqi0EUUwpA	eac4d6164bf243198084a861	7jClmm1R7aOFBDZncFRGX	\N	\N	2026-10-30	adjustment	215900	-215900	Opening Balance	Initial balance as of 2026-10-30	\N	\N	\N	f	\N	\N	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
MHPRecwyHrXQkCkbnqsZs	eac4d6164bf243198084a861	67s9x7MOdc5r82W5ajZhs	\N	\N	2026-10-30	adjustment	394625	-394625	Opening Balance	Initial balance as of 2026-10-30	\N	\N	\N	f	\N	\N	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
pjhLg7Fl1SxJEURnbTM7d	eac4d6164bf243198084a861	GhxaC7BiwNVjbogCdm1Sq	\N	\N	2026-10-30	adjustment	4863535	4863535	Opening Balance	Initial balance as of 2026-10-30	\N	\N	\N	f	\N	\N	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
SMIIWh2Mtc6F2p1Hten35	eac4d6164bf243198084a861	bz6r2FNnApsKuBt7jDn5A	\N	\N	2026-10-30	adjustment	9199500	9199500	Opening Balance	Initial balance as of 2026-10-30	\N	\N	\N	f	\N	\N	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
XLF93hKXdFDFNk8vXtkCT	eac4d6164bf243198084a861	4EPoTUD9RdfYRCs4NwDiu	\N	\N	2026-08-18	adjustment	1500000	1500000	Opening Balance	Initial balance as of 2026-10-30	\N	\N	\N	f	\N	\N	2026-10-30 00:42:52.727+05:30	2026-10-30 13:11:41.911+05:30
FYQ4dOvNB0a9COr3eMjf0	eac4d6164bf243198084a861	NjNv592BrqxfzvA6LxZS7	\N	3b6d8276ef0cd90d7a3fd355	2026-10-30	income	8273300	8273300	KPMG Global Service	\N	\N	req-3yyScNLAhJRlfhNc	\N	f	\N	\N	2026-10-30 13:14:37.84466+05:30	2026-10-30 13:14:37.84466+05:30
fbd8p9M2RTbwZ0QZKtX24	eac4d6164bf243198084a861	KQWpsA9R2izqk8Z7Sm3dT	\N	279507d2fd04d9d7b42a6713	2026-10-30	income	50000	50000	Amazon order	sugu	\N	req-nC273nnG8-73un_P	\N	f	\N	\N	2026-10-30 13:16:26.099247+05:30	2026-10-30 13:16:26.099247+05:30
\.


--
-- Data for Name: fin_user_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fin_user_settings (user_id, base_currency, timezone, week_starts_on, tracking_start_date, setup_step, setup_completed_at, setup_skipped_at, draft, created_at, updated_at) FROM stdin;
eac4d6164bf243198084a861	INR	Asia/Calcutta	1	2026-10-30	6	2026-10-30 00:42:52.727+05:30	\N	\N	2026-10-30 00:27:49.047+05:30	2026-10-30 00:42:52.727+05:30
\.


--
-- Data for Name: fin_valuations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fin_valuations (id, account_id, date, value, cost_basis, note, created_at, updated_at) FROM stdin;
BBxqsZSwZlg4omO7hHYMt	GhxaC7BiwNVjbogCdm1Sq	2026-10-30	5221300	4863535	Opening valuation recorded during setup	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
iuTnZCnkticjvtPCuO1Ns	bz6r2FNnApsKuBt7jDn5A	2026-10-30	8693400	9199500	Opening valuation recorded during setup	2026-10-30 00:42:52.727+05:30	2026-10-30 00:42:52.727+05:30
EXwYCIfMUt565yWAYKkdX	4EPoTUD9RdfYRCs4NwDiu	2026-08-18	1500000	1500000	Opening valuation recorded during setup	2026-10-30 00:42:52.727+05:30	2026-10-30 13:11:41.911+05:30
\.


--
-- Data for Name: folders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.folders (id, workbook_id, kind, name, parent_id, "position", created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.login_attempts (id, key, attempted_at, success) FROM stdin;
qspk2ydMcsHC2VsDi7h41	email:admin@example.com	2026-10-30 00:17:20.215+05:30	f
Jeo1Tssed4kPiVBGsJPqb	ip:172.18.0.1	2026-10-30 00:17:20.215+05:30	f
3CJZDa7gOwU2qTJOkcPvU	email:admin@example.com	2026-10-30 00:18:14.509+05:30	t
7wvGn8SG4fCVGDiAAarwW	ip:172.18.0.1	2026-10-30 00:18:14.509+05:30	t
\.


--
-- Data for Name: queries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.queries (id, workbook_id, name, data_source_id, mode, definition, sql, folder_id, "position", created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schema_cache (data_source_id, snapshot, fetched_at) FROM stdin;
RSnZOSeFecmg9ZJjiPwlp	{"tables": [], "schemas": []}	2026-10-30 00:47:17.369+05:30
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, user_id, token_hash, created_at, expires_at, last_used_at, ip_address, user_agent) FROM stdin;
JTbOVDddAmdfe0Gk0Vkm1	eac4d6164bf243198084a861	d4b058438ae75170776e869ffa806038f7313ebfd7a412cfbb719b7ce5735b1b	2026-10-30 00:18:14+05:30	2026-11-29 13:01:11.333+05:30	2026-10-30 13:01:11.333+05:30	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, name, password_hash, role, status, avatar_url, created_at, updated_at, last_login_at, must_change_password) FROM stdin;
eac4d6164bf243198084a861	admin@example.com	Admin	scrypt$32768$8$1$nM-ECTASQ2N70m19tWj7sA$aZUilvUP6LawPw9Q2UqRDuzvI0ro6Qp92yLS8xdUyBXrP_TT-xjOJSP2EeqT1Kh7XsdqXTaOHIMyLxxKeSc7Iw	admin	active	\N	2026-10-30 00:10:06.074+05:30	2026-10-30 00:18:14.512+05:30	2026-10-30 00:18:14.512+05:30	f
\.


--
-- Data for Name: workbooks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workbooks (id, owner_id, name, slug, description, created_at, updated_at) FROM stdin;
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: postgres
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 5, true);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: postgres
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (key);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: charts charts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.charts
    ADD CONSTRAINT charts_pkey PRIMARY KEY (id);


--
-- Name: dashboard_favorites dashboard_favorites_user_id_dashboard_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_favorites
    ADD CONSTRAINT dashboard_favorites_user_id_dashboard_id_pk PRIMARY KEY (user_id, dashboard_id);


--
-- Name: dashboard_views dashboard_views_user_id_dashboard_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_views
    ADD CONSTRAINT dashboard_views_user_id_dashboard_id_pk PRIMARY KEY (user_id, dashboard_id);


--
-- Name: dashboards dashboards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_pkey PRIMARY KEY (id);


--
-- Name: dashboards dashboards_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_slug_unique UNIQUE (slug);


--
-- Name: data_sources data_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_sources
    ADD CONSTRAINT data_sources_pkey PRIMARY KEY (id);


--
-- Name: data_sources data_sources_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_sources
    ADD CONSTRAINT data_sources_slug_unique UNIQUE (slug);


--
-- Name: data_store_syncs data_store_syncs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_store_syncs
    ADD CONSTRAINT data_store_syncs_pkey PRIMARY KEY (id);


--
-- Name: data_store_tables data_store_tables_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_store_tables
    ADD CONSTRAINT data_store_tables_pkey PRIMARY KEY (id);


--
-- Name: fin_accounts fin_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_accounts
    ADD CONSTRAINT fin_accounts_pkey PRIMARY KEY (id);


--
-- Name: fin_budgets fin_budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_budgets
    ADD CONSTRAINT fin_budgets_pkey PRIMARY KEY (id);


--
-- Name: fin_categories fin_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_categories
    ADD CONSTRAINT fin_categories_pkey PRIMARY KEY (id);


--
-- Name: fin_recurring_rules fin_recurring_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_recurring_rules
    ADD CONSTRAINT fin_recurring_rules_pkey PRIMARY KEY (id);


--
-- Name: fin_transactions fin_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_transactions
    ADD CONSTRAINT fin_transactions_pkey PRIMARY KEY (id);


--
-- Name: fin_user_settings fin_user_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_user_settings
    ADD CONSTRAINT fin_user_settings_pkey PRIMARY KEY (user_id);


--
-- Name: fin_valuations fin_valuations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_valuations
    ADD CONSTRAINT fin_valuations_pkey PRIMARY KEY (id);


--
-- Name: folders folders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_pkey PRIMARY KEY (id);


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_attempts
    ADD CONSTRAINT login_attempts_pkey PRIMARY KEY (id);


--
-- Name: queries queries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queries
    ADD CONSTRAINT queries_pkey PRIMARY KEY (id);


--
-- Name: schema_cache schema_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schema_cache
    ADD CONSTRAINT schema_cache_pkey PRIMARY KEY (data_source_id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_token_hash_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_token_hash_unique UNIQUE (token_hash);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: workbooks workbooks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workbooks
    ADD CONSTRAINT workbooks_pkey PRIMARY KEY (id);


--
-- Name: workbooks workbooks_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workbooks
    ADD CONSTRAINT workbooks_slug_unique UNIQUE (slug);


--
-- Name: charts_folder_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX charts_folder_id_idx ON public.charts USING btree (folder_id);


--
-- Name: charts_query_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX charts_query_id_idx ON public.charts USING btree (query_id);


--
-- Name: charts_workbook_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX charts_workbook_id_idx ON public.charts USING btree (workbook_id);


--
-- Name: dashboard_favorites_dashboard_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dashboard_favorites_dashboard_id_idx ON public.dashboard_favorites USING btree (dashboard_id);


--
-- Name: dashboard_favorites_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dashboard_favorites_user_id_idx ON public.dashboard_favorites USING btree (user_id);


--
-- Name: dashboard_views_dashboard_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dashboard_views_dashboard_id_idx ON public.dashboard_views USING btree (dashboard_id);


--
-- Name: dashboard_views_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dashboard_views_user_id_idx ON public.dashboard_views USING btree (user_id);


--
-- Name: dashboards_folder_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dashboards_folder_id_idx ON public.dashboards USING btree (folder_id);


--
-- Name: dashboards_owner_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dashboards_owner_id_idx ON public.dashboards USING btree (owner_id);


--
-- Name: dashboards_workbook_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dashboards_workbook_id_idx ON public.dashboards USING btree (workbook_id);


--
-- Name: data_sources_owner_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX data_sources_owner_id_idx ON public.data_sources USING btree (owner_id);


--
-- Name: data_store_syncs_started_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX data_store_syncs_started_at_idx ON public.data_store_syncs USING btree (started_at);


--
-- Name: data_store_syncs_table_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX data_store_syncs_table_id_idx ON public.data_store_syncs USING btree (table_id);


--
-- Name: data_store_tables_data_source_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX data_store_tables_data_source_id_idx ON public.data_store_tables USING btree (data_source_id);


--
-- Name: data_store_tables_owner_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX data_store_tables_owner_id_idx ON public.data_store_tables USING btree (owner_id);


--
-- Name: data_store_tables_query_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX data_store_tables_query_id_idx ON public.data_store_tables USING btree (query_id);


--
-- Name: data_store_tables_schema_table_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX data_store_tables_schema_table_idx ON public.data_store_tables USING btree (store_schema, store_table);


--
-- Name: fin_accounts_user_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_accounts_user_active_idx ON public.fin_accounts USING btree (user_id, is_active);


--
-- Name: fin_accounts_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_accounts_user_id_idx ON public.fin_accounts USING btree (user_id);


--
-- Name: fin_accounts_user_kind_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_accounts_user_kind_idx ON public.fin_accounts USING btree (user_id, kind);


--
-- Name: fin_budgets_user_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_budgets_user_category_idx ON public.fin_budgets USING btree (user_id, category_id);


--
-- Name: fin_budgets_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_budgets_user_id_idx ON public.fin_budgets USING btree (user_id);


--
-- Name: fin_categories_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_categories_user_id_idx ON public.fin_categories USING btree (user_id);


--
-- Name: fin_categories_user_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_categories_user_type_idx ON public.fin_categories USING btree (user_id, type);


--
-- Name: fin_recurring_active_next_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_recurring_active_next_idx ON public.fin_recurring_rules USING btree (user_id, is_active, next_occurrence);


--
-- Name: fin_recurring_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_recurring_user_id_idx ON public.fin_recurring_rules USING btree (user_id);


--
-- Name: fin_transactions_account_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_transactions_account_date_idx ON public.fin_transactions USING btree (account_id, date);


--
-- Name: fin_transactions_user_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_transactions_user_category_idx ON public.fin_transactions USING btree (user_id, category_id);


--
-- Name: fin_transactions_user_client_req_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX fin_transactions_user_client_req_idx ON public.fin_transactions USING btree (user_id, client_request_id) WHERE (client_request_id IS NOT NULL);


--
-- Name: fin_transactions_user_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_transactions_user_date_idx ON public.fin_transactions USING btree (user_id, date);


--
-- Name: fin_transactions_user_import_hash_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX fin_transactions_user_import_hash_idx ON public.fin_transactions USING btree (user_id, import_hash) WHERE (import_hash IS NOT NULL);


--
-- Name: fin_valuations_account_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX fin_valuations_account_date_idx ON public.fin_valuations USING btree (account_id, date);


--
-- Name: fin_valuations_account_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_valuations_account_id_idx ON public.fin_valuations USING btree (account_id);


--
-- Name: folders_workbook_id_kind_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX folders_workbook_id_kind_idx ON public.folders USING btree (workbook_id, kind);


--
-- Name: folders_workbook_id_kind_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX folders_workbook_id_kind_name_idx ON public.folders USING btree (workbook_id, kind, name);


--
-- Name: login_attempts_key_attempted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX login_attempts_key_attempted_at_idx ON public.login_attempts USING btree (key, attempted_at);


--
-- Name: queries_data_source_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX queries_data_source_id_idx ON public.queries USING btree (data_source_id);


--
-- Name: queries_folder_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX queries_folder_id_idx ON public.queries USING btree (folder_id);


--
-- Name: queries_workbook_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX queries_workbook_id_idx ON public.queries USING btree (workbook_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sessions_user_id_idx ON public.sessions USING btree (user_id);


--
-- Name: users_email_lower_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_lower_idx ON public.users USING btree (lower(email));


--
-- Name: workbooks_owner_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX workbooks_owner_id_idx ON public.workbooks USING btree (owner_id);


--
-- Name: audit_log audit_log_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: charts charts_folder_id_folders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.charts
    ADD CONSTRAINT charts_folder_id_folders_id_fk FOREIGN KEY (folder_id) REFERENCES public.folders(id) ON DELETE SET NULL;


--
-- Name: charts charts_query_id_queries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.charts
    ADD CONSTRAINT charts_query_id_queries_id_fk FOREIGN KEY (query_id) REFERENCES public.queries(id) ON DELETE CASCADE;


--
-- Name: charts charts_workbook_id_workbooks_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.charts
    ADD CONSTRAINT charts_workbook_id_workbooks_id_fk FOREIGN KEY (workbook_id) REFERENCES public.workbooks(id) ON DELETE CASCADE;


--
-- Name: dashboard_favorites dashboard_favorites_dashboard_id_dashboards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_favorites
    ADD CONSTRAINT dashboard_favorites_dashboard_id_dashboards_id_fk FOREIGN KEY (dashboard_id) REFERENCES public.dashboards(id) ON DELETE CASCADE;


--
-- Name: dashboard_favorites dashboard_favorites_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_favorites
    ADD CONSTRAINT dashboard_favorites_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: dashboard_views dashboard_views_dashboard_id_dashboards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_views
    ADD CONSTRAINT dashboard_views_dashboard_id_dashboards_id_fk FOREIGN KEY (dashboard_id) REFERENCES public.dashboards(id) ON DELETE CASCADE;


--
-- Name: dashboard_views dashboard_views_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_views
    ADD CONSTRAINT dashboard_views_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: dashboards dashboards_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: dashboards dashboards_folder_id_folders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_folder_id_folders_id_fk FOREIGN KEY (folder_id) REFERENCES public.folders(id) ON DELETE SET NULL;


--
-- Name: dashboards dashboards_owner_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_owner_id_users_id_fk FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: dashboards dashboards_workbook_id_workbooks_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_workbook_id_workbooks_id_fk FOREIGN KEY (workbook_id) REFERENCES public.workbooks(id) ON DELETE CASCADE;


--
-- Name: data_sources data_sources_owner_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_sources
    ADD CONSTRAINT data_sources_owner_id_users_id_fk FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: data_store_syncs data_store_syncs_table_id_data_store_tables_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_store_syncs
    ADD CONSTRAINT data_store_syncs_table_id_data_store_tables_id_fk FOREIGN KEY (table_id) REFERENCES public.data_store_tables(id) ON DELETE CASCADE;


--
-- Name: data_store_tables data_store_tables_data_source_id_data_sources_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_store_tables
    ADD CONSTRAINT data_store_tables_data_source_id_data_sources_id_fk FOREIGN KEY (data_source_id) REFERENCES public.data_sources(id) ON DELETE SET NULL;


--
-- Name: data_store_tables data_store_tables_owner_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_store_tables
    ADD CONSTRAINT data_store_tables_owner_id_users_id_fk FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: data_store_tables data_store_tables_query_id_queries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_store_tables
    ADD CONSTRAINT data_store_tables_query_id_queries_id_fk FOREIGN KEY (query_id) REFERENCES public.queries(id) ON DELETE SET NULL;


--
-- Name: fin_accounts fin_accounts_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_accounts
    ADD CONSTRAINT fin_accounts_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fin_budgets fin_budgets_category_id_fin_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_budgets
    ADD CONSTRAINT fin_budgets_category_id_fin_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.fin_categories(id) ON DELETE CASCADE;


--
-- Name: fin_budgets fin_budgets_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_budgets
    ADD CONSTRAINT fin_budgets_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fin_categories fin_categories_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_categories
    ADD CONSTRAINT fin_categories_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fin_recurring_rules fin_recurring_rules_account_id_fin_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_recurring_rules
    ADD CONSTRAINT fin_recurring_rules_account_id_fin_accounts_id_fk FOREIGN KEY (account_id) REFERENCES public.fin_accounts(id) ON DELETE CASCADE;


--
-- Name: fin_recurring_rules fin_recurring_rules_category_id_fin_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_recurring_rules
    ADD CONSTRAINT fin_recurring_rules_category_id_fin_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.fin_categories(id) ON DELETE SET NULL;


--
-- Name: fin_recurring_rules fin_recurring_rules_to_account_id_fin_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_recurring_rules
    ADD CONSTRAINT fin_recurring_rules_to_account_id_fin_accounts_id_fk FOREIGN KEY (to_account_id) REFERENCES public.fin_accounts(id) ON DELETE SET NULL;


--
-- Name: fin_recurring_rules fin_recurring_rules_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_recurring_rules
    ADD CONSTRAINT fin_recurring_rules_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fin_transactions fin_transactions_account_id_fin_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_transactions
    ADD CONSTRAINT fin_transactions_account_id_fin_accounts_id_fk FOREIGN KEY (account_id) REFERENCES public.fin_accounts(id) ON DELETE CASCADE;


--
-- Name: fin_transactions fin_transactions_category_id_fin_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_transactions
    ADD CONSTRAINT fin_transactions_category_id_fin_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.fin_categories(id) ON DELETE SET NULL;


--
-- Name: fin_transactions fin_transactions_to_account_id_fin_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_transactions
    ADD CONSTRAINT fin_transactions_to_account_id_fin_accounts_id_fk FOREIGN KEY (to_account_id) REFERENCES public.fin_accounts(id) ON DELETE SET NULL;


--
-- Name: fin_transactions fin_transactions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_transactions
    ADD CONSTRAINT fin_transactions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fin_user_settings fin_user_settings_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_user_settings
    ADD CONSTRAINT fin_user_settings_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fin_valuations fin_valuations_account_id_fin_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_valuations
    ADD CONSTRAINT fin_valuations_account_id_fin_accounts_id_fk FOREIGN KEY (account_id) REFERENCES public.fin_accounts(id) ON DELETE CASCADE;


--
-- Name: folders folders_workbook_id_workbooks_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_workbook_id_workbooks_id_fk FOREIGN KEY (workbook_id) REFERENCES public.workbooks(id) ON DELETE CASCADE;


--
-- Name: queries queries_data_source_id_data_sources_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queries
    ADD CONSTRAINT queries_data_source_id_data_sources_id_fk FOREIGN KEY (data_source_id) REFERENCES public.data_sources(id) ON DELETE CASCADE;


--
-- Name: queries queries_folder_id_folders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queries
    ADD CONSTRAINT queries_folder_id_folders_id_fk FOREIGN KEY (folder_id) REFERENCES public.folders(id) ON DELETE SET NULL;


--
-- Name: queries queries_workbook_id_workbooks_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queries
    ADD CONSTRAINT queries_workbook_id_workbooks_id_fk FOREIGN KEY (workbook_id) REFERENCES public.workbooks(id) ON DELETE CASCADE;


--
-- Name: schema_cache schema_cache_data_source_id_data_sources_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schema_cache
    ADD CONSTRAINT schema_cache_data_source_id_data_sources_id_fk FOREIGN KEY (data_source_id) REFERENCES public.data_sources(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: workbooks workbooks_owner_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workbooks
    ADD CONSTRAINT workbooks_owner_id_users_id_fk FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict cPcnYnBlIW0PYQJ8ghZaNZG3cx3ud9072didJJv0vemTMi6inO6SPaPWrLk18Ua

